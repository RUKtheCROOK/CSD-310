INSERT INTO DESTINATION(destination_name, destination_description)
    VALUES("Spituk Gompa","An Iconic Hilltop Monastery");
INSERT INTO DESTINATION(destination_name, destination_description)
    VALUES("Dubai Desert Safari","Exciting Desert Adventures");
INSERT INTO DESTINATION(destination_name, destination_description)
    VALUES("Nandi Hills","An ancient hill fortress scattered with monuments and shrines.");
INSERT INTO DESTINATION(destination_name, destination_description)
    VALUES("Grand Canyon","The Grand Canyon of the Colorado River ");
INSERT INTO DESTINATION(destination_name, destination_description)
    VALUES("Iceland Blue Lagoon","The world''s largest geothermal pool");
INSERT INTO DESTINATION(destination_name, destination_description)
    VALUES("Cinque Terre","Hike along the cliffside trail through 5 coastal villages.");

SELECT * FROM Destination;