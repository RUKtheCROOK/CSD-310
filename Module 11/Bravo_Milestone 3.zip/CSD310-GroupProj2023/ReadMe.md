# Status
### Python Code
To get the python files to run you need to pip install the following:
```
pip install mysql-connector-python
pip install PrettyTable
```
### SQL
