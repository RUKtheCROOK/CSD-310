INSERT INTO Registration(trip_id, registration_date, customer_id)
    VALUES(1, ('2022-08-23'), 2);
INSERT INTO Registration(trip_id, registration_date, customer_id)
    VALUES(3,('2022-03-19'), 1);
INSERT INTO Registration(trip_id, registration_date, customer_id)
    VALUES(2,('2021-01-10'), 4);
INSERT INTO Registration(trip_id, registration_date, customer_id)
    VALUES(5,('2023-04-27'), 3);
INSERT INTO Registration(trip_id, registration_date, customer_id)
    VALUES(4, ('2023-10-10'), 6);
INSERT INTO Registration(trip_id, registration_date, customer_id)
    VALUES(6,('2023-01-14'), 5);

SELECT * from Registration